var myPlaylist = [
    {
        mp3:'sample-playlists/1.mp3',
        duration:'0:30',
        cover:'sample-playlists/covers/1.jpg',
        title:'Song Title',
        artist:'Sample',
        background:'sample-playlists/bgs/1.jpg'
    },
    {
        mp3:'sample-playlists/2.mp3',
        duration:'0:30',
        cover:'sample-playlists/covers/2.jpg',
        title:'Song Title',
        artist:'Sample',
        background:'sample-playlists/bgs/2.jpg'
    }
];